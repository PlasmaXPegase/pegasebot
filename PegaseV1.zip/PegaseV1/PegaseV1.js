const Discord = require ('discord.js');
const client = new Discord.Client();
const config = require('./Auth.json')

var prefix = config.prefix

client.on('ready', function(){
		console.log ("PegaseV1 est connecté, Aucun problème à été détecté.") 
		client.user.setActivity("𝔄𝔦𝔡𝔢 𝔓𝔩𝔞𝔰𝔪𝔞 | p/", {type : "STREAMING"
			}) 
});

//OFF COMMAND
client.on("message", function(message){
if (message.content === (prefix + "off")){
	if(!message.member.hasPermission("ADMINISTRATOR")) { return message.channel.send(" **You don't have Permission For that**")}
message.channel.send("_**PEGASEV1 has been Deconnected Of This Server**_")
message.delete().then(client.destroy())
}   
 //PURGE COMMAND
 if(message.content.startsWith(prefix + "purge")){
    if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send("**You don't have the Permission**");
    let args = message.content.split(" ").slice(1)
    if(!args[0]) return message.channel.send("**You have not set the number of messages to delete**")
    message.delete()
    message.channel.bulkDelete(args[0]).then(() => {
        message.channel.send(`**${args[0]} Messages Flew Away :cloud_tornado:**`)
    })
  }
  
});
 //KICK COMMAND
client.on("message", (message) => {
     if (message.content.startsWith(prefix + "kick")) {
           var member= message.mentions.members.first();
           if(!message.member.hasPermission("ADMINISTRATOR")) { return message.channel.send(" **You don't have Permission For that**")};
                 (member.kick().then((member) => 
            (message.channel.send( member.displayName + " **Has Been Correctly Kicked**  ")
          ).catch(() => 
                  message.channel.send("**You don't Have the Permission for That**")))
                 );
              }  
          });
 
 //HELP COMMAND 
client.on('message', message => {
	if(message.content === (prefix + "help")){
  message.channel.send('\n ℙ𝕖𝕘𝕒𝕤𝕖𝕍𝟙 ℍ𝕖𝕝𝕡 𝕄𝕖𝕟𝕦 \n \n 𝕄𝕠𝕕𝕖𝕣𝕒𝕥𝕚𝕠𝕟 \n```p/mod  ```       \n 𝔽𝕌ℕ```p/fun ```\n 𝔸𝕓𝕠𝕦𝕥```p/about```')
	}
 
});
 //BOOM COMMAND
client.on('message', message => {
	if(message.content === (prefix + "boom")){
	if(!message.channel.nsfw) return message.channel.send(" **You're not in an NSFW room!**")
  message.channel.send("https://images-ext-1.discordapp.net/external/nS5HBTASeCwpw3Gw6SsyraDJ8YqtKd5NSKibg10OW2k/https/cdn.discordapp.com/attachments/544714347067342874/546336874550132746/gifdevanture.gif")
	}
 
});
 //MOD MENU
client.on('message', message => {
	if(message.content === (prefix + "mod")){
  message.channel.send('\n 𝕄𝕠𝕕𝕖𝕣𝕒𝕥𝕚𝕠𝕟 𝕄𝕖𝕟𝕦 \n \n 𝕂𝕀ℂ𝕂```Kicked Different Users ||| p/kick (user)``` \n ℙ𝕌ℝ𝔾𝔼```Delete Differents Messages ||| p/purge (numbers)``` \n \n')
	
	}
 
});

//FUN MENU
client.on('message', message => {
	if(message.content === (prefix + "fun")){
  message.channel.send('\n 𝔽𝕌ℕ 𝕄𝕖𝕟𝕦 \n \n 𝔹𝕆𝕆𝕄```(REQUIRE NSFW CHANEL)Send A Good Boom Gif ||| p/boom``` \n \n  ')
	}
 
});
//ABOUT MENU
client.on('message', message => {
	if(message.content === (prefix + "about")){
  ('\n 𝔸𝔹𝕆𝕌𝕋 \n \n ℂℝ𝔼𝔸𝕋𝕆ℝ ```󠇰󠇰"Plasma" | Pegase#0845``` \n 𝕍𝔼ℝ𝕊𝕀𝕆ℕ ```Version Of PegaseV1 : 1.0 ```  \n 𝕋ℍ𝔸ℕ𝕂𝕊 ```Thanks to Sk8rus Server Staff (Tsumiki, Boulax)``` \n \n')
	}
 
});

 client.login(config.token)
 
    